sox $1 $2 pitch +700 10 cubic cos

