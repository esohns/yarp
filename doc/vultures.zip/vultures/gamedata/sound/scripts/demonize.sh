sox $1 $2 pitch -1100 30 cubic cos
