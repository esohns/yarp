sox $1 $2 pitch -1400 40 cubic cos
