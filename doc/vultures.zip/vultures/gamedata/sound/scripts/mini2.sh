sox $1 $2 pitch +1400 10 cubic cos

