sox $1 $2 pitch -700 30 cubic cos
