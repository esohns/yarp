sox $1 $2 phaser 0.6 0.87 3.0 0.9 0.5 -t

