#ifndef VULTURES_NHPLAYERSELECTION_H
#define VULTURES_NHPLAYERSELECTION_H

void vultures_player_selection_internal (void);

#endif
